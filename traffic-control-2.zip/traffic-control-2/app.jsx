import React, { useState, useEffect } from 'react';

// --- Icon Components (can be used directly in React) ---
const MapPin = ({ color = '#000', size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
    <circle cx="12" cy="10" r="3"></circle>
  </svg>
);

const BarChart = ({ color = '#000', size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="20" x2="12" y2="10"></line>
    <line x1="18" y1="20" x2="18" y2="4"></line>
    <line x1="6" y1="20" x2="6" y2="16"></line>
  </svg>
);

const Compass = ({ color = '#000', size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon>
  </svg>
);

const Award = ({ color = '#000', size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="8" r="7"></circle>
    <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
  </svg>
);


// --- 1. Splash / Welcome Screen ---
const SplashScreen = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(onFinish, 2500);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div style={styles.splashContainer}>
      <div className="splash-animation">
        <h1 style={styles.splashTitle}>SmartMove</h1>
        <p style={styles.splashTagline}>AI for Smarter Traffic</p>
      </div>
    </div>
  );
};


// --- 2. Live Traffic Dashboard ---
const LiveTrafficDashboard = ({ navigate }) => (
  <div style={styles.screenContainer}>
    <h2 style={styles.screenTitle}>Live Traffic Dashboard</h2>
    <div style={styles.mapPlaceholder}>
      <p style={styles.mapText}>[ Map View Placeholder ]</p>
      <div style={{...styles.trafficIndicator, backgroundColor: '#28a745', top: '20%', left: '30%' }} />
      <div style={{...styles.trafficIndicator, backgroundColor: '#ffc107', top: '50%', left: '60%' }} />
      <div style={{...styles.trafficIndicator, backgroundColor: '#dc3545', top: '35%', left: '55%' }} />
      <p style={{position: 'absolute', top: '65%', left: '25%', fontWeight: 'bold'}}>🚧 Road Closed</p>
    </div>
    <div style={styles.buttonContainer}>
      <button style={styles.button}>Report Issue</button>
      <button style={styles.button} onClick={() => navigate('PredictiveTraffic')}>Predict Traffic</button>
      <button style={styles.button} onClick={() => navigate('RouteOptimization')}>View Routes</button>
    </div>
  </div>
);


// --- 3. Predictive Traffic Screen ---
const PredictiveTrafficScreen = () => {
  const [mode, setMode] = useState('Now');

  return (
    <div style={styles.screenContainer}>
      <h2 style={styles.screenTitle}>Predictive Traffic</h2>
      <div style={styles.toggleContainer}>
        <button
          style={{ ...styles.toggleButton, ...(mode === 'Now' ? styles.toggleButtonActive : {}) }}
          onClick={() => setMode('Now')}>
          <span style={{ ...styles.toggleText, ...(mode === 'Now' ? styles.toggleTextActive : {}) }}>Now</span>
        </button>
        <button
          style={{ ...styles.toggleButton, ...(mode === 'Predicted' ? styles.toggleButtonActive : {}) }}
          onClick={() => setMode('Predicted')}>
          <span style={{ ...styles.toggleText, ...(mode === 'Predicted' ? styles.toggleTextActive : {}) }}>Predicted (30 mins)</span>
        </button>
      </div>
      <div style={styles.mapPlaceholder}>
         <p style={styles.mapText}>
          {mode === 'Now' ? '[ Live Traffic Heatmap ]' : '[ Predicted Congestion Heatmap ]'}
        </p>
        {mode === 'Predicted' && <div style={styles.heatmapOverlay} />}
      </div>
      <div style={styles.insightCard}>
        <h3 style={styles.insightTitle}>💡 AI Insight</h3>
        <p style={styles.insightText}>
          {mode === 'Now'
            ? 'Heavy congestion reported near Koramangala due to an accident.'
            : 'High probability of congestion near Silk Board in 20 mins due to rain.'}
        </p>
      </div>
    </div>
  );
};


// --- 4. Smart Signal Control (Admin Dashboard) ---
const SmartSignalControl = () => {
    const signalData = [
        { id: '1', name: 'Silk Board Junction', load: 85, waitTime: '120s', mode: 'AI' },
        { id: '2', name: 'Marathahalli Bridge', load: 60, waitTime: '75s', mode: 'AI' },
        { id: '3', name: 'Indiranagar 100ft Rd', load: 45, waitTime: '50s', mode: 'Manual' },
        { id: '4', name: 'Hebbal Flyover', load: 92, waitTime: '145s', mode: 'AI' },
    ];

    return (
        <div style={styles.screenContainer}>
            <h2 style={styles.screenTitle}>Smart Signal Control</h2>
            <div style={styles.tableHeader}>
                <p style={{...styles.headerText, flex: 2}}>Junction</p>
                <p style={{...styles.headerText, flex: 1}}>Load</p>
                <p style={{...styles.headerText, flex: 1}}>Mode</p>
            </div>
            <div>
                {signalData.map(item => (
                    <div key={item.id} style={styles.signalRow}>
                        <div style={{flex: 2}}>
                            <p style={styles.signalName}>{item.name}</p>
                            <p style={styles.signalMeta}>Avg Wait: {item.waitTime}</p>
                        </div>
                        <div style={{flex: 1, alignItems: 'center', textAlign: 'center'}}>
                             <p style={{...styles.signalLoad, color: item.load > 80 ? '#dc3545' : '#ffc107'}}>{item.load}%</p>
                             <p style={styles.signalMeta}>Load</p>
                        </div>
                        <div style={{flex: 1, alignItems: 'center', textAlign: 'center'}}>
                            <span style={{...styles.signalMode, backgroundColor: item.mode === 'AI' ? '#28a745' : '#6c757d'}}>{item.mode}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};


// --- 5. Route Optimization Screen ---
const RouteOptimizationScreen = () => (
    <div style={styles.screenContainer}>
        <h2 style={styles.screenTitle}>Route Optimization</h2>
        <div style={styles.inputGroup}>
            <input placeholder="Source" style={styles.input} defaultValue="HSR Layout" />
            <input placeholder="Destination" style={styles.input} defaultValue="MG Road" />
            <button style={{...styles.button, ...styles.fullWidthButton}}>
                Find Routes
            </button>
        </div>
        <div>
            <div style={{...styles.routeCard, ...styles.routeCardActive}}>
                <h3 style={styles.routeTitle}>Balanced Load Route (AI Recommended)</h3>
                <p style={styles.routeInfo}>14 km · 35 mins · Low Congestion</p>
                <p style={styles.routeMeta}>Reduces overall city traffic by 5%</p>
            </div>
            <div style={styles.routeCard}>
                <h3 style={styles.routeTitle}>Fastest Route</h3>
                <p style={styles.routeInfo}>12 km · 45 mins · High Congestion</p>
                <p style={styles.routeMeta}>Standard Google Maps route</p>
            </div>
            <div style={styles.routeCard}>
                <h3 style={styles.routeTitle}>Eco Route</h3>
                <p style={styles.routeInfo}>15 km · 40 mins · Lowest CO₂</p>
                <p style={styles.routeMeta}>Avoids signals and traffic stops</p>
            </div>
        </div>
    </div>
);


// --- 6. Alerts and Rewards Screen ---
const AlertsAndRewardsScreen = () => {
    const alerts = [
        {id: '1', type: 'WEATHER', text: 'Heavy rain expected in South Bangalore. Drive safe!'},
        {id: '2', type: 'TRAFFIC', text: 'Accident reported on Outer Ring Road. Delays expected.'},
        {id: '3', type: 'REWARD', text: 'You earned 50 points for taking an AI-optimized route!'}
    ];
    
    const leaders = [
        {id: '1', name: 'Ankit S.', points: 2500},
        {id: '2', name: 'Priya M.', points: 2250},
        {id: '3', name: 'Rohan K.', points: 1900},
    ];

    return (
        <div style={{...styles.screenContainer, overflowY: 'auto'}}>
            <h2 style={styles.screenTitle}>Alerts & Rewards</h2>
            <h3 style={styles.subHeader}>Recent Notifications</h3>
            {alerts.map(alert => (
                <div key={alert.id} style={styles.alertCard}>
                    <p style={styles.alertText}>
                        <span style={{fontWeight: 'bold'}}>
                            {alert.type === 'WEATHER' ? '🌧️' : alert.type === 'TRAFFIC' ? '❗' : '⭐'} {alert.type}: {' '}
                        </span>
                        {alert.text}
                    </p>
                </div>
            ))}
            <h3 style={styles.subHeader}>Community Leaderboard</h3>
             {leaders.map((leader, index) => (
                <div key={leader.id} style={styles.leaderboardRow}>
                    <p style={styles.leaderboardRank}>{index + 1}</p>
                    <p style={styles.leaderboardName}>{leader.name}</p>
                    <p style={styles.leaderboardPoints}>{leader.points} pts</p>
                </div>
            ))}
        </div>
    );
};


// --- Main App Component with Navigation ---
export default function App() {
  const [currentScreen, setCurrentScreen] = useState('Splash');

  const renderScreen = () => {
    switch (currentScreen) {
      case 'Dashboard':
        return <LiveTrafficDashboard navigate={setCurrentScreen} />;
      case 'PredictiveTraffic':
        return <PredictiveTrafficScreen />;
      case 'SmartSignal':
        return <SmartSignalControl />;
      case 'RouteOptimization':
        return <RouteOptimizationScreen />;
      case 'Alerts':
        return <AlertsAndRewardsScreen />;
      default:
        return <SplashScreen onFinish={() => setCurrentScreen('Dashboard')} />;
    }
  };
  
  const showNavBar = currentScreen !== 'Splash';

  return (
    <div style={styles.container}>
      <main style={styles.content}>
        {renderScreen()}
      </main>
      {showNavBar && (
         <nav style={styles.navBar}>
            <button style={styles.navButton} onClick={() => setCurrentScreen('Dashboard')}>
                <MapPin color={currentScreen === 'Dashboard' ? '#007AFF' : '#8E8E93'} />
                <span style={{...styles.navText, color: currentScreen === 'Dashboard' ? '#007AFF' : '#8E8E93'}}>Dashboard</span>
            </button>
            <button style={styles.navButton} onClick={() => setCurrentScreen('SmartSignal')}>
                <BarChart color={currentScreen === 'SmartSignal' ? '#007AFF' : '#8E8E93'} />
                <span style={{...styles.navText, color: currentScreen === 'SmartSignal' ? '#007AFF' : '#8E8E93'}}>Signals</span>
            </button>
            <button style={styles.navButton} onClick={() => setCurrentScreen('RouteOptimization')}>
                <Compass color={currentScreen === 'RouteOptimization' ? '#007AFF' : '#8E8E93'} />
                <span style={{...styles.navText, color: currentScreen === 'RouteOptimization' ? '#007AFF' : '#8E8E93'}}>Routes</span>
            </button>
             <button style={styles.navButton} onClick={() => setCurrentScreen('Alerts')}>
                <Award color={currentScreen === 'Alerts' ? '#007AFF' : '#8E8E93'} />
                <span style={{...styles.navText, color: currentScreen === 'Alerts' ? '#007AFF' : '#8E8E93'}}>Rewards</span>
            </button>
        </nav>
      )}
    </div>
  );
}


// --- Stylesheet (CSS-in-JS for React web) ---
const styles = {
  container: { display: 'flex', flexDirection: 'column', height: '100vh', backgroundColor: '#F0F0F7', fontFamily: 'sans-serif' },
  content: { flex: 1, overflowY: 'auto' },
  splashContainer: { flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#007AFF' },
  splashTitle: { fontSize: 48, fontWeight: 'bold', color: '#FFF' },
  splashTagline: { fontSize: 18, color: '#FFF', marginTop: 8 },
  screenContainer: { flex: 1, padding: 16 },
  screenTitle: { fontSize: 28, fontWeight: 'bold', marginBottom: 20, color: '#1C1C1E' },
  mapPlaceholder: {
    height: 300,
    backgroundColor: '#E5E5EA',
    borderRadius: 16,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  mapText: { color: '#8E8E93', fontSize: 16, fontWeight: '500' },
  trafficIndicator: { width: 15, height: 15, borderRadius: '50%', position: 'absolute', borderWidth: 2, borderColor: 'rgba(255,255,255,0.7)' },
  buttonContainer: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between' },
  button: { cursor: 'pointer', border: 'none', backgroundColor: '#007AFF', color: '#FFF', padding: '12px 10px', borderRadius: 12, flex: 1, margin: '0 5px', textAlign: 'center', fontSize: 14, fontWeight: '600' },
  toggleContainer: { display: 'flex', flexDirection: 'row', backgroundColor: '#E5E5EA', borderRadius: 12, marginBottom: 20, padding: 4 },
  toggleButton: { cursor: 'pointer', border: 'none', flex: 1, padding: '10px 0', borderRadius: 10, alignItems: 'center', backgroundColor: 'transparent' },
  toggleButtonActive: { backgroundColor: '#FFF', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' },
  toggleText: { fontSize: 16, fontWeight: '600', color: '#3A3A3C' },
  toggleTextActive: { color: '#007AFF' },
  heatmapOverlay: { position: 'absolute', width: '100%', height: '100%', backgroundColor: 'rgba(255, 100, 0, 0.3)', borderRadius: 16 },
  insightCard: { backgroundColor: '#FFF', padding: 16, borderRadius: 12, marginTop: 10 },
  insightTitle: { fontSize: 16, fontWeight: 'bold', color: '#1C1C1E', marginBottom: 5, marginTop: 0 },
  insightText: { fontSize: 14, color: '#3A3A3C', lineHeight: 1.5, margin: 0 },
  tableHeader: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between', padding: '0 10px 10px 10px', borderBottom: '1px solid #E5E5EA' },
  headerText: { fontWeight: 'bold', color: '#8E8E93', textAlign: 'left' },
  signalRow: { display: 'flex', flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', padding: 15, borderRadius: 12, marginBottom: 10 },
  signalName: { fontSize: 16, fontWeight: '600', color: '#1C1C1E', margin: 0 },
  signalMeta: { fontSize: 12, color: '#8E8E93', marginTop: 2, margin: 0 },
  signalLoad: { fontSize: 18, fontWeight: 'bold', margin: 0 },
  signalMode: { fontSize: 12, color: '#FFF', fontWeight: 'bold', padding: '4px 8px', borderRadius: 6, overflow: 'hidden' },
  inputGroup: { marginBottom: 20 },
  input: { boxSizing: 'border-box', width: '100%', backgroundColor: '#FFF', padding: 15, borderRadius: 12, marginBottom: 10, fontSize: 16, border: '1px solid #E5E5EA' },
  fullWidthButton: { flex: 'none', margin: 0, width: '100%' },
  routeCard: { backgroundColor: '#FFF', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 2, borderStyle: 'solid', borderColor: 'transparent' },
  routeCardActive: { borderColor: '#007AFF', backgroundColor: '#E5F1FF' },
  routeTitle: { fontSize: 16, fontWeight: 'bold', color: '#1C1C1E', margin: 0 },
  routeInfo: { fontSize: 14, color: '#3A3A3C', margin: '4px 0' },
  routeMeta: { fontSize: 12, color: '#007AFF', fontWeight: '500', margin: 0 },
  subHeader: { fontSize: 20, fontWeight: 'bold', color: '#1C1C1E', marginTop: 15, marginBottom: 10 },
  alertCard: { backgroundColor: '#FFF', padding: 15, borderRadius: 12, marginBottom: 10 },
  alertText: { fontSize: 14, color: '#3A3A3C', lineHeight: 1.5, margin: 0 },
  leaderboardRow: { display: 'flex', flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', padding: '12px 16px', borderRadius: 12, marginBottom: 8 },
  leaderboardRank: { fontSize: 16, fontWeight: 'bold', color: '#8E8E93', width: 30 },
  leaderboardName: { flex: 1, fontSize: 16, fontWeight: '500', color: '#1C1C1E' },
  leaderboardPoints: { fontSize: 16, fontWeight: 'bold', color: '#007AFF' },
  navBar: { display: 'flex', flexDirection: 'row', height: 60, backgroundColor: '#FFF', borderTop: '1px solid #E5E5EA' },
  navButton: { cursor: 'pointer', border: 'none', backgroundColor: 'transparent', flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: 10 },
  navText: { fontSize: 10, marginTop: 4 },
};